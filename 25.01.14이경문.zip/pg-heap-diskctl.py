#https://school.programmers.co.kr/learn/courses/30/lessons/42627
# from collections import deque

# job = []
# pause = deque()
# hard = []
# def solution(jobs):
#     for i, num in enumerate(jobs):
#         job.append([num[0],num[1],i]) # 작업 요청시간, 작업 소요시간, 작업 번호
#     job.sort(key = lambda x : (x[1], x[0],x[2]))
    
#     job_temp = deque(job)
    
#     time = 0
#     for i in range(i[])
#         if time == job_temp[0]
    
    
# print(solution([[0, 3], [1, 9], [3, 5]]))

# 진짜 어려움....
# 정답 코드
import heapq

def solution(jobs):
    # jobs를 요청 시간 기준으로 정렬
    jobs.sort(key=lambda x: x[0])

    heap = []  # (소요 시간, 요청 시간)을 담을 최소 힙
    time, total_time, job_index, completed_jobs = 0, 0, 0, 0
    n = len(jobs)

    while completed_jobs < n:
        # 현재 시간까지 요청된 작업을 힙에 추가
        while job_index < n and jobs[job_index][0] <= time:
            heapq.heappush(heap, (jobs[job_index][1], jobs[job_index][0]))
            job_index += 1

        if heap:
            # 소요 시간이 가장 짧은 작업을 꺼내 처리
            job_duration, job_request_time = heapq.heappop(heap)
            time += job_duration  # 작업 처리 시간 추가
            total_time += (time - job_request_time)  # 대기 시간 + 처리 시간
            completed_jobs += 1
        else:
            # 처리할 작업이 없으면 시간 증가
            time += 1

    # 평균 작업 시간 반환
    return total_time // n

# 테스트 케이스
print(solution([[0, 3], [1, 9], [3, 5]]))  # 출력: 9
