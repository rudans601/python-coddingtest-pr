n = int(input())
t = []
p = []
for _ in range(n):
    a,b = map(int,input().split())
    t.append(a)
    p.append(b)

for i in range(n):
    for j in range(i,n):
        p[j + t[j]] = max(p[j + t[j]],p[j]+p[j + t[j]])

print(max(p))